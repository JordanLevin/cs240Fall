#include "FBLPost.h"

FBLPost::FBLPost(std::string t){
    text = t;
}
